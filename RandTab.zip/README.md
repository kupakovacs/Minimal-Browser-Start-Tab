# COMPLETELY RANDOM Wikipedia Image New TAb

Want a great relaxing experience for your new tab, and also want to learn something new each day? This extension is for you.
